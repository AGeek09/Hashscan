# Copyright [2024] [ALOK PUROHIT]

#Licensed under the Apache License, Version 2.0 (the "License");
#you may not use this file except in compliance with the License.
#You may obtain a copy of the License at

  #  http://www.apache.org/licenses/LICENSE-2.0

import tkinter as tk
from tkinter import messagebox, scrolledtext
import os
import hashlib
import socket
from datetime import datetime

class HashScannerApp:
    def __init__(self, master):
        self.master = master
        self.master.title("File Hash Scanner | Developed by : ALOK PUROHIT ")

        # Input for hash
        self.hash_label = tk.Label(master,anchor=tk.CENTER,       
                 #bg="yellow",      
                 height=1,              
                 width=90,              
                 bd=3,                  
                 font=("Display", 10, "bold"), 
                   
                 fg="darkblue",             
                 padx=5,               
                 pady=5,                
                 justify=tk.CENTER,    
                 relief=tk.FLAT,     
                 #underline=0,           
                 wraplength=750, text=" # Developed by ALOK PUROHIT , OpenSource Licensed under the Apache License, Version 2.0 ")

        self.hash_label.pack(pady=5)
        self.hash_label = tk.Label(master,anchor=tk.CENTER,       
                 bg="lightgreen",      
                 height=1,              
                 width=30,              
                 bd=3,                  
                 font=("Arial", 10, "bold"), 
                   
                 fg="black",             
                 padx=5,               
                 pady=5,                
                 justify=tk.CENTER,    
                 relief=tk.FLAT,     
                 #underline=0,           
                 wraplength=250, text="Enter File Hash (MD5/SHA1/SHA256):")
        self.hash_label.pack(pady=5)

        self.hash_entry = tk.Entry(master, width=50)
        self.hash_entry.pack(pady=5)

        # Input for hash type
        self.hash_type_label = tk.Label(master,anchor=tk.CENTER,       
                 bg="lightblue",      
                 height=1,              
                 width=30,              
                 bd=3,                  
                 font=("Arial", 10, "bold"), 
                   
                 fg="black",             
                 padx=5,               
                 pady=5,                
                 justify=tk.CENTER,    
                 relief=tk.FLAT,     
                 #underline=0,           
                 wraplength=250, text=" Select Hash Type: ")
        self.hash_type_label.pack(pady=5)

        self.hash_type_var = tk.StringVar(value="MD5")
        self.md5_radio = tk.Radiobutton(master,  text="MD5", font=("Arial", 10, "bold") ,  variable=self.hash_type_var, value="MD5" )
        self.md5_radio.pack(anchor=tk.CENTER)
        
        self.sha1_radio = tk.Radiobutton(master, text="SHA1" ,font=("Arial", 10, "bold"),  variable=self.hash_type_var, value="SHA1")
        self.sha1_radio.pack(anchor=tk.CENTER)

        self.sha256_radio = tk.Radiobutton(master, text="SHA256",font=("Arial", 10, "bold"), variable=self.hash_type_var, value="SHA256")
        self.sha256_radio.pack(anchor=tk.CENTER)

        # Input for directory path
        self.dir_label = tk.Label(master,anchor=tk.CENTER,       
                 bg="lightyellow",      
                 height=2,              
                 width=50,              
                 bd=3,                  
                 font=("Arial", 10, "bold"), 
                   
                 fg="black",             
                 padx=5,               
                 pady=5,                
                 justify=tk.CENTER,    
                 relief=tk.FLAT,
                            
                 wraplength=550, text="Enter Directory Path to Scan (leave empty for entire system):")
        
        self.dir_label.pack(pady=5)

        self.dir_entry = tk.Entry(master, width=50)
        self.dir_entry.pack(pady=5)

        # Start scan button
        self.start_button = tk.Button(master, bg="lightgreen" ,text="Scan System",cursor="hand2", font=("Arial", 10, "bold" ), justify=tk.CENTER,    
                 relief=tk.RAISED, command=self.scan_system)
        self.start_button.pack(pady=10)
        
        
        # Results display
        self.results_text = scrolledtext.ScrolledText(master, width=80, height=20)
        self.results_text.pack(pady=10)

    def scan_system(self):
        target_hash = self.hash_entry.get().strip()
        directory_path = self.dir_entry.get().strip() or "/"  # Default to root if empty

        if not target_hash:
            messagebox.showerror("Error", "Please enter a hash.")
            return

        # Get hostname and IP address
        hostname = socket.gethostname()
        ip_address = socket.gethostbyname(hostname)

        log_file_path = "hash_scan_results.txt"
        
        with open(log_file_path, 'w') as log_file:
            log_file.write("Hostname, IP Address, File Path, Result, Timestamp\n")  # CSV header
            
            total_files_scanned = 0
            matched_files = 0
            
            self.results_text.delete(1.0, tk.END)  # Clear previous results
            self.results_text.insert(tk.END, "Scanning system for files...\n")
            
            # Start scanning the specified directory or entire system
            for root, dirs, files in os.walk(directory_path):
                for file in files:
                    total_files_scanned += 1
                    file_path = os.path.join(root, file)
                    file_hash = self.calculate_file_hash(file_path)
                    
                    if file_hash and file_hash == target_hash:
                        matched_files += 1
                        result_message = f"Hash matched: {file_path}"
                        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        log_file.write(f"{hostname}, {ip_address}, {file_path}, {result_message}, {timestamp}\n")
                        self.results_text.insert(tk.END, f"{result_message} at {timestamp}\n")

                    # Update progress every 100 files scanned
                    if total_files_scanned % 100 == 0:  
                        progress_message = f"Scanned {total_files_scanned} files..."
                        self.results_text.insert(tk.END, f"{progress_message}\n")
                        self.results_text.see(tk.END)  # Scroll to the end of the text area

            final_message = f"Scan completed. Total files scanned: {total_files_scanned}, Matched files: {matched_files}.\n"
            self.results_text.insert(tk.END, final_message)

    def calculate_file_hash(self, file_path):
        """Calculate the hash of the specified file based on selected hash type."""
        
        hash_type = self.hash_type_var.get()
        
        try:
            if hash_type == "MD5":
                hash_obj = hashlib.md5()
            elif hash_type == "SHA1":
                hash_obj = hashlib.sha1()
            elif hash_type == "SHA256":
                hash_obj = hashlib.sha256()
            else:
                return None
            
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_obj.update(chunk)
            
            return hash_obj.hexdigest()
        
        except Exception as e:
            return None  # Return None if there's an error (e.g., permission denied)

if __name__ == "__main__":
    root = tk.Tk()
    app = HashScannerApp(root)
    root.mainloop()